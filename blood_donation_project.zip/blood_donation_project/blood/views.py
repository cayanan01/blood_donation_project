from django.views.generic import CreateView
from django.shortcuts import redirect
from .models import DonationRequest
from django.urls import reverse_lazy
from django.views.generic import UpdateView, DeleteView

class DonationRequestCreateView(CreateView):
    model = DonationRequest
    fields = ['request_type', 'blood_type', 'region', 'province', 'municipality']
    template_name = 'blood/donation_request_form.html'
    success_url = reverse_lazy('donation_list')

    def form_valid(self, form):
        donation_request = form.save(commit=False)
        donation_request.user = self.request.user
        profile = self.request.user.profile
        if donation_request.request_type == 'donating':
            # Auto-fill fields from the profile
            donation_request.blood_type = profile.blood_type
            donation_request.region = profile.region
            donation_request.province = profile.province
            donation_request.municipality = profile.municipality
            if not profile.availability:
                form.add_error('request_type', 'You cannot create a donation request if your availability is False.')
                return self.form_invalid(form)
        return super().form_valid(form)

    class DonationRequestUpdateView(UpdateView):
        model = DonationRequest
        fields = ['region', 'province', 'municipality']
        template_name = 'blood/donation_request_update.html'
        success_url = reverse_lazy('donation_list')

    class DonationRequestDeleteView(DeleteView):
        model = DonationRequest
        template_name = 'blood/donation_request_confirm_delete.html'
        success_url = reverse_lazy('donation_list')