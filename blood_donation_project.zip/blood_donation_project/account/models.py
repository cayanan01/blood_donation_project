
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager
from django.db import models

class UserManager(BaseUserManager):
    def create_user(self, username, email, password=None):
        if not email:
            raise ValueError('Users must have an email address')
        user = self.model(username=username, email=self.normalize_email(email))
        user.set_password(password)
        user.save(using=self._db)
        return user

class User(AbstractBaseUser):
    username = models.CharField(max_length=255, unique=True)
    email = models.EmailField(max_length=255, unique=True)
    active = models.BooleanField(default=True)
    staff = models.BooleanField(default=False)
    admin = models.BooleanField(default=False)

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['username']

    objects = UserManager()

    class Profile(models.Model):
        user = models.OneToOneField(User, on_delete=models.CASCADE)
        first_name = models.CharField(max_length=255)
        last_name = models.CharField(max_length=255)
        weight = models.FloatField()
        height = models.FloatField()
        region = models.CharField(max_length=100)
        province = models.CharField(max_length=100)
        municipality = models.CharField(max_length=100)
        blood_type = models.CharField(max_length=5)
        availability = models.BooleanField(default=True)
        last_donation_date = models.DateField(null=True, blank=True)


class Profile:
    pass