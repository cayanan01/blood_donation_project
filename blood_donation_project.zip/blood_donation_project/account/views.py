from django.shortcuts import render, redirect
from django.contrib.auth import get_user_model
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import authenticate, login as auth_login
from .models import Profile
from django.contrib.auth.decorators import login_required
from blood.models import DonationRequest
from django.views.generic import UpdateView
from django.utils import timezone
from django.urls import reverse_lazy


def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
    else:
        form = UserCreationForm()
    return render(request, 'account/register.html', {'form': form})

def login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            if Profile.objects.filter(user=user).exists():
                auth_login(request, user)
                return redirect('home')
            else:
                return redirect('create_profile')
    return render(request, 'account/login.html')

@login_required
def profile_view(request):
    profile = Profile.objects.get(user=request.user)
    blood_requests = DonationRequest.objects.filter(user=request.user)
    return render(request, 'account/profile.html', {'profile': profile, 'blood_requests': blood_requests})

class ProfileUpdateView(UpdateView):
    model = Profile
    fields = ['first_name', 'last_name', 'weight', 'height', 'region', 'province', 'municipality', 'availability']
    template_name = 'account/profile_update.html'
    success_url = reverse_lazy('profile')

    def form_valid(self, form):
        profile = form.save(commit=False)
        # Prevent changing availability if last donation was less than 56 days ago
        if profile.availability:
            if (timezone.now().date() - profile.last_donation_date).days < 56:
                form.add_error('availability', 'You cannot change availability to True before 56 days after last donation.')
                return self.form_invalid(form)
        return super().form_valid(form)