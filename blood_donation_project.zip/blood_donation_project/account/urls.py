from django.urls import path
from . import views
from .views import profile_view, ProfileUpdateView

urlpatterns = [
    path('register/', views.register, name='register'),

]
urlpatterns += [
    path('profile/', profile_view, name='profile'),
    path('profile/update/', ProfileUpdateView.as_view(), name='profile_update'),
]